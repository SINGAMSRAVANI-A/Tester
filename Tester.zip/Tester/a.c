#include <stdio.h>
struct product
{
	int prodid;
	char prodname[25];
	float price;
}vt;
int main()
{
	FILE *fp1;
	struct product p;
	int i,n,r1,r2,recno,d;
	fp1=fopen("vtu.bin","wb+");
	printf("How many records to enter\n");
	scanf("%d",&n);
	for(i=0; i<n; i++)
	{
		printf("Enter prodid, prodname, price");
		scanf("%d %s %f",&p.prodid,p.prodname,&p.price);
		fwrite(&p,sizeof(vt),1,fp1);
	}
	rewind(fp1);
	while(fread(&p,sizeof(vt),1,fp1)==1)
	{
		printf("%d %s %f\n",p.prodid,p.prodname,p.price);
	}
	rewind(fp1);
	printf("Enter range to be printed\n");
	scanf("%d%d",&r1,&r2);
	d=r2-r1+1;
	recno = r1%10;
	fseek(fp1,(recno-1)*sizeof(vt), SEEK_SET);
	for(i=0; i<d; i++)
	{
		fread(&p,sizeof(p),1,fp1);
		printf("%d %s %f\n",p.prodid,p.prodname,p.price);
	}
	fclose(fp1);
	return 0;
}
